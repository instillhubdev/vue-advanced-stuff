<template>
  <button type="button" class="btn btn-blue">
    <slot></slot>
  </button>
</template>

<script>
export default {}
</script>

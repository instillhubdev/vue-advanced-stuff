<script>
export default {
  render() {
    return this.$scopedSlots.default({})
  }
}
</script>
